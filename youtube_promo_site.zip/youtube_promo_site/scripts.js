// Simple fade-in effect for cards
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".channel-card");
  cards.forEach((card, i) => {
    card.style.opacity = "0";
    setTimeout(() => {
      card.style.transition = "opacity 0.8s ease";
      card.style.opacity = "1";
    }, i * 300);
  });
});

// Optional scroll animation
window.addEventListener("scroll", () => {
  const header = document.querySelector("header");
  if (window.scrollY > 50) {
    header.style.background = "#111";
    header.style.transition = "0.3s";
  } else {
    header.style.background = "transparent";
  }
});