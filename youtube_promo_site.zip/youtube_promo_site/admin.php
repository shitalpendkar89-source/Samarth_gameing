<?php
session_start();
if (!isset($_SESSION["admin"])) {
  header("Location: login.php");
  exit;
}

$dataFile = "data.json";
$data = json_decode(file_get_contents($dataFile), true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $data["channels"][0]["name"] = $_POST["ch1_name"];
  $data["channels"][0]["link"] = $_POST["ch1_link"];
  $data["channels"][0]["desc"] = $_POST["ch1_desc"];
  $data["channels"][1]["name"] = $_POST["ch2_name"];
  $data["channels"][1]["link"] = $_POST["ch2_link"];
  $data["channels"][1]["desc"] = $_POST["ch2_desc"];
  file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
  $msg = "✅ Changes saved successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h2>🔥 Admin Panel</h2>
<p><a href="logout.php">Logout</a></p>
<?php if (isset($msg)) echo "<p style='color:lime;'>$msg</p>"; ?>

<form method="POST">
  <h3>Channel 1</h3>
  <input type="text" name="ch1_name" value="<?= $data['channels'][0]['name'] ?>" required><br>
  <input type="text" name="ch1_link" value="<?= $data['channels'][0]['link'] ?>" required><br>
  <textarea name="ch1_desc" rows="3"><?= $data['channels'][0]['desc'] ?></textarea><br>

  <h3>Channel 2</h3>
  <input type="text" name="ch2_name" value="<?= $data['channels'][1]['name'] ?>" required><br>
  <input type="text" name="ch2_link" value="<?= $data['channels'][1]['link'] ?>" required><br>
  <textarea name="ch2_desc" rows="3"><?= $data['channels'][1]['desc'] ?></textarea><br>

  <button type="submit">💾 Save Changes</button>
</form>
</body>
</html>